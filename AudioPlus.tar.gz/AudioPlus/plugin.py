#!/usr/bin/python
# -*- coding: utf-8 -*-
# by digiteng 08.2021

from Plugins.Plugin import PluginDescriptor
from six.moves import reload_module
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
import os
import sys
import time
from Components.config import config, configfile, ConfigSubsection, ConfigPassword, getConfigListEntry
from Components.ConfigList import ConfigListScreen
import base64
import requests
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from enigma import addFont

addFont("/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/fonts/LiberationSans-Regular.ttf", "Regular", 100, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/fonts/LiberationSans-Bold.ttf", "Console", 100, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/fonts/digicon.ttf", "di", 100, 1)

version = "v3.0"
PY3 = sys.version_info[0] == 3
try:
	if PY3:
		# from future import standard_library
		from builtins import str
		from configparser import ConfigParser
	else:
		from ConfigParser import ConfigParser
except:
	pass
	
try:
	lang = config.osd.language.value[:-3]
except:
	pass
	
# try:
	# if not os.path.exists("/tmp/mac"):
		# try:
			# os.system("ifconfig eth0 | awk '/HWaddr/ {printf $5}' > /tmp/mac")
		# except:
			# if not os.path.exists("/tmp/mac"):
				# try:
					# import netifaces
					# mac = netifaces.ifaddresses('eth0')
					# mac = mac[netifaces.AF_LINK][0]['addr']
					# with open("/tmp/mac", "w") as f:
						# f.write(str(mac))
				# except:
					# if not os.path.exists("/tmp/mac"):
						# try:
							# from Components.Network import iNetwork
							# mcl = []
							# ifaces = iNetwork.getConfiguredAdapters()
							# for iface in ifaces:
								# mcl.append(iNetwork.getAdapterAttribute(iface, "mac"))
							# with open("/tmp/mac", "w") as f:
								# f.write(str(mcl))
						# except:
							# pass
# except:
	# pass
	
lng = ConfigParser()
lng.read('/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/languages')
V1dwWk1HTXlWVDA9 = base64.b64decode
WTBkR01HRkJQVDA9 = "VEROV2VtTnBPWE5oVjBsMldsYzFjRm95TVdoTmFUbDNaVmhTYjJJeU5IWlZSM2d4V2pKc2RXTjVPVVpsU0ZKc1ltNU9jR0l5TlhwTU1FWXhXa2RzZGxWSGVERmplVGc5"
WTBkR01HRkJQVDA9 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WTBkR01HRkJQVDA9))).decode("utf-8")
V20xc2MxcFJQVDA9 = "WWtkT2MyUnRUWFZqU0dzOQ=="
V20xc2MxcFJQVDA9 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V20xc2MxcFJQVDA9))).decode("utf-8")
WTBoU2IxcHRkejA9 = "{}{}".format(WTBkR01HRkJQVDA9, V20xc2MxcFJQVDA9)

config.plugins.ap = ConfigSubsection()
config.plugins.ap.actv = ConfigPassword(default='', fixed_size=False, censor='*')
config.plugins.ap.actv.setUseableChars(u'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

class CheckActv(Screen, ConfigListScreen):
	skin = '''
<screen name="CheckActv" position="center,center" size="640,400" flags="wfNoBorder" backgroundColor="#50112030">
	<eLabel name="" text="AudioPlus {}" position="0,0" size="640,30" font="Regular; 26" foregroundColor="#00ffffff" backgroundColor="#3478c1" zPosition="1" halign="center" valign="center" transparent="0" />
	<widget name="info" position="20,40" font="Regular; 28" size="600,40" foregroundColor="#00ffffff" backgroundColor="#50112030" zPosition="1" transparent="1" halign="left" valign="center" />
	<widget name="config" position="20,190" size="600,40" itemHeight="40" font="fi;30" foregroundColor="#c5c5c5" transparent="0" backgroundColor="#000000" />
	<widget source="key_red" render="Label" backgroundColor="#222222" position="0,360" size="160,30" transparent="0" font="Regular; 18" zPosition="1" halign="center" valign="bottom" />
	<widget source="key_green" render="Label" backgroundColor="#222222" position="160,360" size="160,30" transparent="0" font="Regular; 18" zPosition="1" halign="center" valign="bottom" />
	<widget source="key_yellow" render="Label" backgroundColor="#222222" position="320,360" size="160,30" transparent="0" font="Regular; 18" zPosition="1" halign="center" valign="bottom" />
	<widget source="key_blue" render="Label" backgroundColor="#222222" position="480,360" size="160,30" transparent="0" font="Regular; 18" zPosition="1" halign="center" valign="bottom" />
	<eLabel name="r" position="0,390" size="160,10" transparent="0" backgroundColor="#ef4c4c" />
	<eLabel name="g" position="160,390" size="160,10" transparent="0" backgroundColor="#4cef83" />
	<eLabel name="y" position="320,390" size="160,10" transparent="0" backgroundColor="#efcf4c" />
	<eLabel name="b" position="480,390" size="160,10" transparent="0" backgroundColor="#4cc1ef" />
</screen>'''.format(version)

	def __init__(self, session):
		Screen.__init__(self, session)

		self.list = []
		# self.list.append(getConfigListEntry(_('Code'), config.plugins.ap.actv))
		ConfigListScreen.__init__(self, self.list)
		
		self['key_red'] = Label(_('Close'))
		self['key_green'] = Label(_(lng.get(lang, 'actv')))
		self['key_yellow'] = Label(_(lng.get(lang, 'actvCdimp')))
		# self['key_blue'] = Label(_(None))
		self["actions"] = ActionMap(["AudioPlusAction"],
			{
				"cancel":self.exit,
				"ok":self.exit,
				"red":self.exit,
				"green": self.cntrlAct,
				"yellow": self.imprtCode
				# "blue": self.exit,
			}, -1)
		self['info'] = Label(_(lng.get(lang, 'actvCd')))
		self.inActCode()

	def inActCode(self):
		self.list = []
		self.list.append(getConfigListEntry('礠 Code', config.plugins.ap.actv))
		self["config"].list = self.list
		self["config"].setList(self.list)
		
	def cntrlAct(self):
		# self['info'].setText("ok.")
		# pass
		try:
			WTBoT00yTnRVVDA9 = config.plugins.ap.actv.value
			WkVjNWNscFhORDA9 = 'V2pKb2QxZ3lOVkZSYmtKTlRqRlNVbHB1V1hkU1ZteEdXbXBHUmxscVJtMWtWWFI2VWxWd2RWb3hjRmRqYWxFelVsaHZNMDEzUFQwPQ=='
			WWpOa2RWcFlTVDA9 = 'V2tkc2JtRllVbXhpYldNOQ=='
			WTIxV2QySjNQVDA9 = 'V1ZoQlBRPT0='
			V20xc2MxcFJQVDA9 = 'VEcxV2RXUm5QVDA9'
			V201V2VXSkJQVDA9 = 'WVVoU01HTklUVFpNZVRsb1kwZHJkVm95YkRCaFNGWnBURzFPZG1KVE9YbGFXRUoyWTNrNU4yWlRPVGRtVXpscVlqSTFNRnBYTlRCamVUazNabEU5UFE9PQ=='
			h0 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9("WVVkV2FGcEhWbmxqZHowOQ=="))).decode("utf-8")
			h1 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9("V1ZkT2FscFlRakE9"))).decode("utf-8")
			h2 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9("V1ZoQ2QySkhiR3BaV0ZKd1lqSTBkbVJ0Tld0TWJXUndaRWRvTVZscE5USk5lVFY1V1ZoalBRPT0="))).decode("utf-8")
			h3 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9("V1ZoV01HRkhPWGxoV0hCb1pFZHNkbUpuUFQwPQ=="))).decode("utf-8")
			h4 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9("WkVjNWNscFhORDA9"))).decode("utf-8")
			cc = 'WVVoU01HTklUVFpNZVRsb1kwZHJkVm95YkRCaFNGWnBURzFPZG1KVE9YbGFXRUoyWTNrNU4yWlRPVGRtVXpscVlqSTFNRnBYTlRCamVUazNabEU5UFE9PQ=='
			e1 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WWpOa2RWcFlTVDA9))).decode("utf-8")
			e2=V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WTIxV2QySjNQVDA9))).decode("utf-8")
			e3=V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V20xc2MxcFJQVDA9))).decode("utf-8")
			WkZoS2MyTjNQVDA9 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(cc))).decode("utf-8").format(e1, e2, e3)
			WVVkV2FGcEhWbms9={'{}'.format(h1): '{}'.format(h2),'{}'.format(h3): '{} {}'.format(h4, V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WkVjNWNscFhORDA9))).decode("utf-8"))}
			WkZoS2MyTjNQVDA9 = requests.get(WkZoS2MyTjNQVDA9, stream=True, allow_redirects=True, headers=WVVkV2FGcEhWbms9)
		except Exception as err:
			with open("/tmp/error.log", "a+") as f:
				f.write("cntrlAct-plugin1\n%s\n\n"%err)
		try:
			if WkZoS2MyTjNQVDA9.status_code == 200:
				chckon = False
				for i in WkZoS2MyTjNQVDA9.text.split():
					if i == WTBoT00yTnRVVDA9:
						V20xc2MxcFJQVDA9 = 'WWtkT2MyUnRUWFZqU0dzOQ=='
						WkZoS2MxcDNQVDA9 = V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V201V2VXSkJQVDA9))).decode("utf-8").format(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WWpOa2RWcFlTVDA9))).decode("utf-8"), V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WTIxV2QySjNQVDA9))).decode("utf-8"), V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V20xc2MxcFJQVDA9))).decode("utf-8"))
						WVVkV2FGcEhWbms9 = {'{}'.format(h1): '{}'.format(h2),'{}'.format(h3): '{} {}'.format(h4, V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(V1dwWk1HTXlWVDA9(WkVjNWNscFhORDA9))).decode("utf-8"))}
						WkZoS2MyTjNQVDA9 = requests.get(WkZoS2MxcDNQVDA9, stream=True, allow_redirects=True, headers=WVVkV2FGcEhWbms9)
						if WkZoS2MyTjNQVDA9.status_code == 200:
							open(WTBoU2IxcHRkejA9, 'w').write(requests.get(WkZoS2MxcDNQVDA9, stream=True, allow_redirects=True, headers=WVVkV2FGcEhWbms9).text)
							chck = lng.get(lang, 'actvS')
							configfile.save()
							chckon = True
							self.session.openWithCallback(self.restartGUI, MessageBox, _(lng.get(lang, 'actvS')), MessageBox.TYPE_YESNO)

				if chckon != True:
					chck = lng.get(lang, 'actvSno')
					try:
						if os.path.exists("{}".format(WTBoU2IxcHRkejA9)):
							os.remove("{}".format(WTBoU2IxcHRkejA9))
							os.remove("{}o".format(WTBoU2IxcHRkejA9))
					except Exception as err:
						with open("/tmp/error.log", "a+") as f:
							f.write("cntrlAct-plugin2\n%s\n\n"%err)

		except Exception as err:
			with open("/tmp/error.log", "a+") as f:
				f.write("cntrlAct-plugin3\n%s\n\n"%err)
		self['info'].setText(str(chck))

	def imprtCode(self):
		if os.path.exists("/tmp/activationCode.txt"):
			with open("/tmp/activationCode.txt", "r") as f:
				actvCode = f.read()
			config.plugins.ap.actv.value = actvCode
			for x in self["config"].list:
				if len(x)>1:
					x[1].save()
				configfile.save()
			self.session.open(MessageBox, _(lng.get(lang, 'actvOk')), MessageBox.TYPE_INFO, timeout = True)
			self['info'].setText(lng.get(lang, 'actvCdimpOn'))
		else:
			self['info'].setText(lng.get(lang, 'actvCdNot'))
			
	def restartGUI(self, answer):
		try:
			if answer is True:
				self.session.open(TryQuitMainloop, 3)
			else:
				self.close()
		except:
			self.close()

	def exit(self):
		for x in self["config"].list:
			if len(x)>1:
				x[1].save()
		configfile.save()
		self.close(True)

def main(session, **kwargs):
	try:
		if not os.path.exists("{}".format(WTBoU2IxcHRkejA9)):
			session.open(CheckActv)
		elif os.path.exists("{}".format(WTBoU2IxcHRkejA9)):
			# from Plugins.Extensions.AudioPlus.lclvc import lclvc
			from . import lclvc
			reload_module(lclvc)
			session.open(lclvc.lclvc)

	except:
		pass

def Plugins(**kwargs):
	list=[]
	list.append(PluginDescriptor(name="AudioPlus", description="background audio playback...", where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main))
	return list
	