from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, eEPGCache, eTimer, eListboxPythonMultiContent, iPlayableService, eConsoleAppContainer, iPlayableService, getDesktop, eServiceCenter, getBestPlayableServiceReference
from Components.SelectionList import SelectionList, SelectionEntryComponent
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigText, ConfigInteger, ConfigSelectionNumber, ConfigDirectory
from Components.ConfigList import ConfigListScreen
import os
from Components.VolumeBar import VolumeBar
from Components.MenuList import MenuList
from Components.Sources.List import List
from Components.ProgressBar import ProgressBar
from Components.VolumeBar import VolumeBar

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Button import Button
from Screens.MessageBox import MessageBox
from Screens.InfoBar import MoviePlayer, InfoBar
from enigma import eServiceReference, iServiceInformation
from Components.MenuList import MenuList
from GlobalActions import globalActionMap
try:
	from keymapparser import readKeymap
except:
	from Components.ActionMap import loadKeymap as readKeymap
from Components.Sources.StaticText import StaticText
from Components.config import config, ConfigInteger, getConfigListEntry, ConfigSelection, ConfigYesNo, ConfigSubsection ,ConfigText ,configfile , ConfigDirectory
from Components.ConfigList import ConfigList, ConfigListScreen
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
from enigma import eConsoleAppContainer , getDesktop , eTimer , eListboxPythonMultiContent , gFont , RT_HALIGN_RIGHT, RT_HALIGN_LEFT, RT_VALIGN_CENTER , RT_WRAP
from Components.ServiceEventTracker import ServiceEventTracker
from Components.MultiContent import MultiContentEntryText
from Tools.Directories import fileExists
from ServiceReference import ServiceReference
from enigma import iPlayableService 

import os, time ,sys
from Components.Sources.List import List
from Screens.Standby import TryQuitMainloop


epgcache = eEPGCache.getInstance()
config.plugins.lvlaudio = ConfigSubsection()
config.plugins.lvlaudio.vol2 = ConfigSelection(default = "0", choices = ["0", "10", "20", "40", "50", "60", "70", "80", "90", "100"])
config.plugins.lvlaudio.vol5 = ConfigYesNo()
	

config.plugins.lvlaudio.audio = ConfigYesNo()

config.plugins.lvlaudio.vol = ConfigSelectionNumber(0, 100, 5, default=30)

config.plugins.lvlaudio.updt = ConfigYesNo(default=True)
config.plugins.lvlaudio.sync = ConfigSelection(default="alsasink", choices = [
				("alsasink", _("alsasink")),
				("osssink", _("osssink")),
				("autoaudiosink", _("autoaudiosink")),
			])
config.plugins.lvlaudio.lastidx = ConfigText()


class lclvc(Screen):

	skin = """
	<screen position="center,center" size="1000,600" title="..." backgroundColor="#50000000">
		<widget name="Volume" position="800,20" size="150,20" foregroundColor="#ffffff" borderColor="#ffffff" borderWidth="1"  backgroundColor="#50000000" zPosition="1" />
		<widget name="vlmtext" position="700,20" size="100,40" transparent="1" font="Regular;20" foregroundColor="#ffffff" backgroundColor="#50000000" halign="left" valign="top" />
		<widget name="list" position="25,150" size="950,400" itemHeight="40" font="Regular;30" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#50000000" backgroundColorSelected="#565d6d" foregroundColorSelected="#ffffff" />
		<widget source="key_red" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#7f0202" position="25,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_green" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#116b07" position="250,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_yellow" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#a08426" position="475,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_blue" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#0000ff" position="700,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget name="status" position="25,10" size="950,40" transparent="1" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#50000000" halign="left" valign="center" />
		<widget name="info" position="25,50" size="950,40" transparent="1" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#50000000" halign="left" valign="top" />
	</screen>
	"""
	
	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		# self.vlmlist = config.plugins.lvlaudio.vol.value
		# self.vlmlist = [0.0, 0.03, 0.05, 0.08, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9, 1.0]
		self.vlmlist = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7,0.8, 0.9, 1.0]
		self.vlm = 0
		self.vol = 0.3
		self["list"] = MenuList([])
		# self["list"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		
		self['key_red'] = Label(_('Close'))
		self['key_green'] = Label(_('-'))
		self['key_yellow'] = Label(_('-'))
		self['key_blue'] = Label(_('Reset'))
		self["actions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions", "NavigationActions","MenuActions", "GlobalActions"],
		{
			"left": self.volDown,
			"right": self.volUp,
			# "down": self.keyDown,
			# "up": self.keyUp,
			
			"ok": self.keyOk,
			# "green": self.volDown,
			# "yellow": self.volUp,
			"blue": self.resetAudio,
			"cancel": self.exit,
			"menu": self.mn,
			"volumeUp": self.volUp,
			"volumeDown": self.volDown
			
		}, -1)
		
		self.onCh = self.session.nav.getCurrentlyPlayingServiceReference()
		self.container = eConsoleAppContainer()

		self.volumeBar = VolumeBar()
		self['Volume'] = self.volumeBar
	
		self.setTitle(_("LocalVoice v1.0"))
		self['status'] = Label(_('_'))
		self['info'] = Label(_("_"))
		self['vlmtext'] = Label(_("_"))
		self.timer = eTimer()
		self.timer.callback.append(self.audioList)
		self.timer.callback.append(self.getCurrentService)
		self.timer.callback.append(self.mc)

		self.timer.start(100, True)

	def delay(self):
		self.timer.start(100, True)		
		
	def audioList(self):
		self.setValue()
		# self['status'].setText(_(str()))
		if os.path.exists("/tmp/audio.m3u"):
			try:
				with open("/tmp/audio.m3u") as f:
					m=f.read()
				m = m.replace("#EXTINF:-1,","").replace("#EXTM3U","").strip()
				m = m.split("\n")

				list=[]
				for i in range(1, len(m), 2):
					url = m[i]
					list.append((getConfigListEntry(" Audio %s"%i, url)))
			except:
				pass
			self["list"].list = list
			self["list"].l.setList(list)
		else:
			list=[]
			url = "http://195.150.20.7/rmf_fm"
			list.append((getConfigListEntry("Test Radio", url)))
			self["list"].list = list
			self["list"].l.setList(list)


	def keyOk(self):
		self.resetAudio()
		self.timer.callback.append(self.urlAudio)
		self.timer.start(100, True)
		
	def volDown(self):
		try:
			self.vlm -=1
			self.vol =  self.vlmlist[self.vlm]
			if not self.vol >= 0.1:
				return
			self.setValue()
			self.changePlaylist()
			self.delay()
		except:
			pass
			
	def volUp(self):
		try:
			self.vlm +=1
			self.vol =  self.vlmlist[self.vlm]
			if not self.vol <= 1.0:
				return
			self.setValue()
			self.changePlaylist()
			self.delay()
		except:
			pass
			
	def setValue(self):
		try:
			
			# if self.vol < 1/10:
				# v = 1000
			# else:
				# v = 100
			
			self.volumeBar.setValue(int(self.vol*100))
			self['vlmtext'].setText(_("VOL : {}".format(int(self.vol*100))))
			# self['VolumeText'].text = str(self.vol)
		except:
			pass


	def urlAudio(self):
		# self.resetAudio()
		sync = "alsasink"
		url = self['list'].l.getCurrentSelection()[1]
		if os.path.exists('/dev/dvb/adapter0/audio0'):
			self.session.nav.stopService()
			os.rename('/dev/dvb/adapter0/audio0', '/dev/dvb/adapter0/audioX')
			self.session.nav.playService(self.onCh)
			sync = config.plugins.lvlaudio.sync.value
			self.container.execute('gst-launch-1.0 playbin uri={} audio-sink={} volume={}'.format(url, sync, self.vlmlist[self.vlm]))

	def changePlaylist(self):
		if self.vlm > (len(self.vlmlist)-1):
		   self.vlm = 0
		if self.vlm < 0:
		   self.vlm = len(self.vlmlist)-1
		self.audioList()

	def chAudio(self):
		if os.path.exists('/dev/dvb/adapter0/audioX'):
			self.session.nav.stopService()
			os.rename('/dev/dvb/adapter0/audioX', '/dev/dvb/adapter0/audio0')
			self.session.nav.playService(self.onCh)
			
	def killAudio(self):
		os.system('killall -9 gst-launch-1.0 >/dev/null 2>&1')
		if self.container.running():
			self.container.kill()
		self.chAudio()
		
	def resetAudio(self):
		self.killAudio()
		self.chAudio()


		
	def mc(self): # mac adress e2 stb
		import netifaces
		mac = netifaces.ifaddresses('eth0')
		mac = mac[netifaces.AF_LINK][0]['addr']
		self['info'].setText("Mac Adress : %s"%str(mac))
		
	def getCurrentService(self):
		try:
			events = None
			ref = self.session.nav.getCurrentlyPlayingServiceReference().toString()
			events = epgcache.lookupEvent(['IBDTSENRX', (ref, 2)])[0][6]
			self['status'].setText(_("Channel : %s"%events))
		except Exception as e:
			self['status'].setText(_(str(e)))
			
	def mn(self):
		self.session.open(Stp)
		
	def exit(self):
		configfile.save()
		self.close()

class Stp(Screen, ConfigListScreen):
	skin = """
	<screen position="center,center" size="1000,600" title="..." backgroundColor="#50000000">

		<widget name="config" position="25,10" size="950,400" itemHeight="40" font="Regular;30" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#50000000" backgroundColorSelected="#565d6d" foregroundColorSelected="#ffffff" />
		<widget source="key_red" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#7f0202" position="25,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_green" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#116b07" position="250,545" size="200,30" halign="center" transparent="0" zPosition="1" />

	</screen>
	"""

	
	def __init__(self, session):
		Screen.__init__(self, session)

		list = []
		ConfigListScreen.__init__(self, list, session=session, on_change=self.changedEntry)
		self.onChangedEntry = []
		self["actions"] = ActionMap(["SetupActions"],
			{
				"cancel":self.close,
				"save":self.save,
				"ok":self.save,
			}, -2)
		self['key_red'] = Label(_('Close'))
		self['key_green'] = Label(_('Save'))
		self.setTitle(_("LocalVoice v1.0"))
		self.mn()
	
	def mn(self):
		list = []
		list.append((getConfigListEntry(" AUDIO SINK", config.plugins.lvlaudio.sync)))
		list.append((getConfigListEntry(" UPDATE", config.plugins.lvlaudio.updt)))
		
		self["config"].list = list
		self["config"].setList(list)
	
	def save(self):
		for x in self["list"].list:
			if len(x)>1:
				x[1].save()
		configfile.save()
		self.close(True)
	
	def changedEntry(self):
		for x in self.onChangedEntry:
			x()	
	
	
