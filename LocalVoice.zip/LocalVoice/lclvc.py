from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, eEPGCache, eTimer, iPlayableService, eConsoleAppContainer, iPlayableService, getDesktop, eServiceCenter, getBestPlayableServiceReference
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigText, ConfigInteger, ConfigSelectionNumber, ConfigDirectory
from Components.ConfigList import ConfigListScreen
import os
from Screens.ChannelSelection import ChannelSelection
from ServiceReference import ServiceReference
from Components.VideoWindow import VideoWindow
from Screens.PictureInPicture import PictureInPicture
import time
from Components.MenuList import MenuList
from Components.Sources.List import List

epgcache = eEPGCache.getInstance()
config.plugins.lvlaudio = ConfigSubsection()
config.plugins.lvlaudio.audioSelect = ConfigSelection(default = "default", choices = [("default"), ("audio_2"), ("audio_3")])

class lclvc(Screen, ConfigListScreen):
	skin = """
	<screen position="center,center" size="1000,600" title="..." backgroundColor="#50000000">
		<widget name="config" position="25,150" size="950,400" itemHeight="40" font="Regular;30" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#50000000" backgroundColorSelected="#565d6d" foregroundColorSelected="#ffffff" />
		<widget source="key_red" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#7f0202" position="25,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_green" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#116b07" position="250,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_yellow" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#a08426" position="475,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget source="key_blue" render="Label" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#0000ff" position="700,545" size="200,30" halign="center" transparent="0" zPosition="1" />
		<widget name="status" position="25,10" size="950,40" transparent="1" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#50000000" halign="left" valign="center" />
		<widget name="info" position="25,50" size="950,40" transparent="1" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#50000000" halign="left" valign="top" />
	</screen>
	"""
	
	def __init__(self, session):
		Screen.__init__(self, session)

		self['key_red'] = Label(_('Close'))
		self['key_green'] = Label(_('url-Audio'))
		self['key_yellow'] = Label(_('-'))
		self['key_blue'] = Label(_('Reset'))
		self["actions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions", "NavigationActions"],
		{
			"left": self.keyLeft,
			"down": self.keyDown,
			"up": self.keyUp,
			"right": self.keyRight,
			"ok": self.keyOk,
			"green": self.keyOk,
			# "yellow": self.urlAudio,
			"blue": self.resetAudio,
			"cancel": self.exit,

		}, -1)
		# self.mc()
		list = []
		ConfigListScreen.__init__(self, list, session=session)
		self['config'] = MenuList(list)
		self.setTitle(_("LocalVoice v1.0"))
		self['status'] = Label(_('_'))
		self['info'] = Label(_("_"))
		self.onCh = self.session.nav.getCurrentlyPlayingServiceReference()
		self.container = eConsoleAppContainer()
		self.timer = eTimer()
		self.timer.callback.append(self.audioList)
		self.timer.callback.append(self.getCurrentService)
		self.timer.callback.append(self.mc)
		self.timer.start(100, True)

	def delay(self):
		self.timer.start(100, True)

	def keyLeft(self):
		try:
			ConfigListScreen.keyLeft(self)
			self.delay()
		except:
			pass
			
	def keyRight(self):
		try:
			ConfigListScreen.keyRight(self)
			self.delay()
		except:
			pass
			
	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.delay()

	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.delay()

	def pageUp(self):
		self["config"].instance.moveSelection(self["config"].instance.pageDown)
		self.delay()

	def pageDown(self):
		self["config"].instance.moveSelection(self["config"].instance.pageUp)
		self.delay()
		
	def audioList(self):
		# for x in self["config"].list:
			# if len(x) > 1:
				# x[1].save()

		if os.path.exists("/tmp/audio.m3u"):
			try:
				with open("/tmp/audio.m3u") as f:
					m=f.read()
				m = m.replace("#EXTINF:-1,","").replace("#EXTM3U","").strip()
				m = m.split("\n")

				list=[]
				for i in range(1, len(m), 2):
					url = m[i]
					list.append((getConfigListEntry("Audio %s"%i, url)))
			except:
				pass
			self["config"].list = list
			self["config"].l.setList(list)
		else:
			list=[]
			url = "http://195.150.20.7/rmf_fm"
			list.append((getConfigListEntry("Test Radio", url)))
			self["config"].list = list
			self["config"].l.setList(list)





	def keyOk(self):
		self.resetAudio()
		self.timer.callback.append(self.urlAudio)
		self.timer.start(100, True)

	def urlAudio(self):
		# self.resetAudio()
		url = self['config'].l.getCurrentSelection()[1]
		
		if os.path.exists('/dev/dvb/adapter0/audio0'):
			
			self.session.nav.stopService()
			os.rename('/dev/dvb/adapter0/audio0', '/dev/dvb/adapter0/audioX')
			self.session.nav.playService(self.onCh)
			# url = "http://195.150.20.7/rmf_fm"
			# self['status'].setText(str(url))
			
			self.container.execute('gst-launch-1.0 playbin uri={} audio-sink=alsasink'.format(url))
			
	def chAudio(self):
		if os.path.exists('/dev/dvb/adapter0/audioX'):
			self.session.nav.stopService()
			os.rename('/dev/dvb/adapter0/audioX', '/dev/dvb/adapter0/audio0')
			self.session.nav.playService(self.onCh)
			
	def killAudio(self):
		os.system('killall -9 gst-launch-1.0 >/dev/null 2>&1')
		if self.container.running():
			self.container.kill()
		self.chAudio()
		
	def resetAudio(self):
		self.killAudio()
		self.chAudio()
		
	def mc(self): # mac adress e2 stb
		import netifaces
		mac = netifaces.ifaddresses('eth0')
		mac = mac[netifaces.AF_LINK][0]['addr']
		self['info'].setText("Mac Adress : %s"%str(mac))
		
	def getCurrentService(self):
		try:
			events = None
			ref = self.session.nav.getCurrentlyPlayingServiceReference().toString()
			events = epgcache.lookupEvent(['IBDTSENRX', (ref, 2)])[0][6]
			self['status'].setText(_("Channel : %s"%events))
		except Exception as e:
			self['status'].setText(_(str(e)))
			
	def exit(self):
		configfile.save()
		self.close()
		