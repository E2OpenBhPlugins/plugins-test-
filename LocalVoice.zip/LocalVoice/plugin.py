
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Pixmap import Pixmap
from Components.Label import Label
from enigma import getDesktop
import lclvc


def main(session, **kwargs):
	reload(lclvc)
	try:
		session.open(lclvc.lclvc)
	except:
		import traceback
		traceback.print_exc()

def Plugins(**kwargs):
	return [PluginDescriptor(name="lclvc", description="lclvc plugin...", where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)]
